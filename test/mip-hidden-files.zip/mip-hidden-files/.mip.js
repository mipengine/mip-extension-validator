define(function (require) {
    /**
     * desc
     *
     * @type {Object}
     */
    var a = {
    };

    return a;
});
