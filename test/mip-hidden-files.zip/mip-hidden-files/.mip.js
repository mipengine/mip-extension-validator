var a=1;
