/**
 * @file jquery.js
 * @author mengke01(kekee000@gmail.com)
 */
