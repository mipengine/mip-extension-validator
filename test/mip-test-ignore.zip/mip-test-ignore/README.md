# mip-test-ignore

mip-test-ignore 组件说明

标题|内容
----|----
类型|通用
支持布局|responsive,fixed-height,fill,container,fixed
所需脚本|http://mipcache.bdstatic.com/static/v1/mip-test-ignore/mip-test-ignore.js

## 示例

### 基本用法
```html
<mip-test-ignore>
    自定义内容，可以嵌套其他组件
</mip-test-ignore>
```

## 属性

### {属性名}

说明：{说明}
必选项：{是|否}
类型：{类型}
取值范围：{取值范围}
单位：{单位}
默认值：{默认值}

## 注意事项

